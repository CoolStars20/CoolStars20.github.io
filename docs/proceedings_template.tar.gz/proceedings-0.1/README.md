CS20 Proceedings
================
LaTeX and BibTeX style files for compiling proceedings to the 20th Cambridge Workshop
on Cool Stars, Stellar Systems, and the Sun.

Many thanks to the CS19 team that complied these style files and made them availalbe for re-use!